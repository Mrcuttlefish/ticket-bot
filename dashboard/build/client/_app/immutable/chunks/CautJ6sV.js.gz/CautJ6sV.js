import{av as a}from"./XDDRZcps.js";a();
