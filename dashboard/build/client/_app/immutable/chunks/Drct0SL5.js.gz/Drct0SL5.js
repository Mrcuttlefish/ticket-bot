import{ax as a}from"./D2YrtNCE.js";a();
